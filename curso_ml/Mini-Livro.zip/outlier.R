# Gerando um novo conjunto de dados
set.seed(42)
n <- 1000
x <- rnorm(n = n,mean = 0,sd = 0.5)
n_out <- 5
sample_out <- sample(1:n,size = n_out)
x[sample_out] <- (rnorm(n = n_out,sd = 3))^2

# Gerando o modelo
library(kernlab)
outlier_svm <- ksvm(x,type= "one-svc",nu = 0.8, kernel = "vanilladot")

# Visualizando os resultados
plot(1:n,x, type = "l")
outliers <- which(predict(outlier_svm))
points(outliers,x[outliers],pch=20, col = "red")
